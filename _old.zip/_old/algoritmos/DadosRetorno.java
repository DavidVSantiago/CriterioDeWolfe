package algoritmos;
import data_structures.Vec2;

public class DadosRetorno{
    public Vec2 X;
    public double stepSize;
    public DadosRetorno(Vec2 X, double stepSize){
        this.X=X;
        this.stepSize=stepSize;
    }
}

package data_structures;
public class Vec2 {
    // atributos
    public double x,y;

    public Vec2(double x, double y){
        this.x=x;
        this.y=y;
    }
}
